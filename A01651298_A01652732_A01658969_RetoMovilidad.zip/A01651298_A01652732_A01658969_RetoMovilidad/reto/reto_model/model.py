from mesa import Agent, Model
from mesa.time import RandomActivation
from mesa.space import MultiGrid
import random
import json

lista = []
cars = []
lights = []

class RetoModel(Model):

    def __init__(self, N=1, width=11, height=11):
        self.num_agents = N
        self.grid = MultiGrid(height, width, True)
        self.schedule = RandomActivation(self)

        directions = ["right", "right"]

        # Create agents
        for i in range(self.num_agents):
            direction = directions[random.randint(0,1)]
            a = Car(i, self, direction)
            self.schedule.add(a)
            # Add the agent to a random grid cell
            if direction == 'right':
                #x = self.random.randrange(self.grid.width)
                #y = 5
                x=0
                y=5
            if direction == 'up':
                x = 5
                y = self.random.randrange(self.grid.height)
            self.grid.place_agent(a, (x, y))

        a = TrafficLight(10, self, 0)
        b = TrafficLight(11, self, 1)
        self.schedule.add(a)
        self.schedule.add(b)
        self.grid.place_agent(a, (4, 5))
        self.grid.place_agent(b, (5, 4))

        self.running = True

    def step(self):
        global lista
        global cars
        global lights
        cars = []
        lights = []
        self.schedule.step()
        # ordena cars x id
        carsOrdenada = sorted(cars, key=lambda d: d['id'])
        for s in carsOrdenada:
	        remove_key = s.pop("id", None)
        # ordena luces x id
        lightsOrdenada = sorted(lights, key=lambda d: d['id'])
        for s in lightsOrdenada:
	        remove_key = s.pop("id", None)
        return json.dumps({
            "cars": carsOrdenada,
            "lights": lightsOrdenada
        })

    def run_model(self, n):
        for i in range(n):
            self.step()

class TrafficLight(Agent):
  def __init__(self,name,model,state):
    super().__init__(name,model)
    self.type=10
    self.state=state
    self.counter=0

  def save(self):
    global lights
    objeto = {
        "id": self.unique_id,
        "status": self.state,
    }
    lights.append(objeto)

  def step(self):
    self.save()

    listA = self.model.grid.get_cell_list_contents((4, 5))
    listB = self.model.grid.get_cell_list_contents((5, 4))

    if len(listA) > 0:
        for i in listA:
            if i.type == 10:
                semaforoA = i

    if len(listB) > 0:
        for i in listB:
            if i.type == 10:
                semaforoB = i

    # si está lleno el primero
    if not self.model.grid.is_cell_empty((3,5)) and not self.model.grid.is_cell_empty((2,5)) and not self.model.grid.is_cell_empty((1,5)):
        semaforoA.state=1
        semaforoB.state=0
        semaforoA.counter=0
        semaforoB.counter=0

    # si está lleno el segundo
    if not self.model.grid.is_cell_empty((5,3)) and not self.model.grid.is_cell_empty((5,2)) and not self.model.grid.is_cell_empty((5,1)):
        semaforoB.state=1
        semaforoA.state=0
        semaforoA.counter=0
        semaforoB.counter=0

    self.counter = self.counter+1
    if self.counter % 30 == 0:
        if self.state == 0:
            self.state = 1
        else:
            self.state = 0
        

class Car(Agent):
    """An agent with fixed initial wealth."""

    def __init__(self, unique_id, model,_direction):
        super().__init__(unique_id, model)
        self.type=2
        self.direction=_direction
        self.moving=True
        self.chosenDir=False

    def move(self):

        if self.chosenDir==False:
            # checamos intersecciones
            if self.pos == (5, 5):
                self.direction = ["right", "up"][random.randint(0,1)]
                self.chosenDir=True

            if self.pos == (5, 0):
                self.direction = ["left", "up"][random.randint(0,1)]
                self.chosenDir=True

            if self.pos == (0, 5):
                self.direction = ["up", "right"][random.randint(0,1)]
                self.chosenDir=True

        # checamos límites
        if self.direction == 'right':
            if self.pos[0] + 1 == 11:
                self.direction = 'down'

        if self.direction == 'down':
            if self.pos[1] - 1 == -1:
                self.direction = 'left'

        if self.direction == 'up':
            if self.pos[1] + 1 == 11:
                self.direction = 'right'

        if self.direction == 'left':
            if self.pos[0] - 1 == -1:
                self.direction = 'up'

        # checamos casilla de enfrente
        if self.direction == 'right':
            siguiente = self.model.grid.get_cell_list_contents((self.pos[0] + 1, self.pos[1]))
        if self.direction == 'down':
            siguiente = self.model.grid.get_cell_list_contents((self.pos[0], self.pos[1] - 1))
        if self.direction == 'up':
            siguiente = self.model.grid.get_cell_list_contents((self.pos[0], self.pos[1] + 1))
        if self.direction == 'left':
            siguiente = self.model.grid.get_cell_list_contents((self.pos[0] - 1, self.pos[1]))


        if len(siguiente) > 0:
            for i in siguiente:

                if i.type == 2:
                    self.moving=False
                else:
                    self.moving=True

                #checamos si la siguiente es un semaforo
                if i.type == 10:
                    if i.state == 0:
                        self.moving=False
                    else:
                        self.moving=True
        else:
            self.moving = True

        if self.moving:
            if self.direction == 'right':
                new_position = (self.pos[0] + 1, self.pos[1])
                self.model.grid.move_agent(self, new_position)
                self.chosenDir = False
            if self.direction == 'up':
                new_position = (self.pos[0], self.pos[1] + 1)
                self.model.grid.move_agent(self, new_position)
                self.chosenDir = False
            if self.direction == 'left':
                new_position = (self.pos[0] - 1, self.pos[1])
                self.model.grid.move_agent(self, new_position)
                self.chosenDir = False
            if self.direction == 'down':
                new_position = (self.pos[0], self.pos[1] - 1)
                self.model.grid.move_agent(self, new_position)
                self.chosenDir = False

    def save(self):
        global cars
        objeto = {
            "id": self.unique_id,
            "x": self.pos[0],
            "y": self.pos[1],
            "direction": self.direction
        }
        cars.append(objeto)

    def step(self):
        self.save()
        self.move()
        