from reto_model.server import server

server.launch()
