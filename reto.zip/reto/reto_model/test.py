from model import RetoModel
from flask import Flask
app = Flask(__name__)

empty_model = RetoModel(10)

@app.route("/")
def hello_world():
    global empty_model
    toprint = empty_model.step()
    return str(toprint)

if __name__ == "__main__":
    app.run()