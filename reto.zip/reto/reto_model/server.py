from mesa.visualization.ModularVisualization import ModularServer
from .model import RetoModel

from mesa.visualization.modules import CanvasGrid
from mesa.visualization.modules import ChartModule
from mesa.visualization.UserParam import UserSettableParameter

def agent_portrayal(agent):
    portrayal = {"Shape": "circle", "Filled": "true", "r": 0.5}

    if agent.type == 2:
        if agent.direction=='right':
            portrayal["Color"] = "gray"
            portrayal["Layer"] = 1
        if agent.direction=='up':
            portrayal["Color"] = "gray"
            portrayal["Layer"] = 1
        if agent.direction=='down':
            portrayal["Color"] = "gray"
            portrayal["Layer"] = 1
        if agent.direction=='left':
            portrayal["Color"] = "gray"
            portrayal["Layer"] = 1

    if agent.type == 10:
        if agent.state == 1:
            portrayal["Color"] = "green"
            portrayal["Layer"] = 1
        else:
            portrayal["Color"] = "red"
            portrayal["Layer"] = 1
    return portrayal

grid = CanvasGrid(agent_portrayal, 11, 11, 500, 500)

model_params = {
    "N": UserSettableParameter(
        "slider",
        "Number of agents",
        1,
        1,
        10,
        1,
        description="Choose how many agents to include in the model",
    ),
    "width": 11,
    "height": 11,
}

server = ModularServer(RetoModel, [grid], "Reto Model", model_params)
server.port = 8521
